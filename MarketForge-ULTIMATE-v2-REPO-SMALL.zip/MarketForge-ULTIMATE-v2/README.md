# MarketForge ULTIMATE

Original Android financial-market strategy sandbox inspired by the genre of market simulators. It is not a copy of proprietary source code, branding or assets.

## Gameplay
- Live simulated prices and volume ticks
- Price impact from player order size
- Order book and Time & Sales
- Market catalysts, bull runs and crashes
- Ten fictional companies across sectors
- Portfolio, P&L, missions, career, rivals, company growth and IPO
- Persistent save data
- Portrait-first mobile UI
- Large build-time content pack generated in CI, keeping the Git repository small while producing a substantial APK

## Build
Use JDK 17 and Gradle 8.10. The GitHub workflow discovers the actual Android project root recursively, then builds `assembleDebug`.

## Repository size / APK size
The repository intentionally contains no large binary asset pack. GitHub Actions generates a ~115 MiB content pack during the build and packages it into the APK. The exact final APK size depends on Android packaging/compression.
