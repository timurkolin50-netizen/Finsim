# MarketForge ULTIMATE

Android trading simulator with a small Git repository and a large build-time content pack.

## Build

GitHub Actions installs Gradle 8.10.2 and Android SDK 35, generates the build-time content pack, and builds `app-debug.apk`.

The repository intentionally does **not** contain the large generated asset pack. `tools/generate_content_pack.py` creates it during CI before Gradle builds the APK.

Workflow: `.github/workflows/build-apk.yml`

## GitHub

Upload the contents of this project to the repository root. The repository remains well below a 25 MB limit because generated build content is excluded from Git.

## APK

The generated content pack is approximately 115 MiB. It is placed in `app/src/main/assets/generated/` during the workflow and therefore becomes part of the APK. The final APK size is determined by Android packaging and can be checked in the `Verify APK` step.
