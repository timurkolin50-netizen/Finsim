#!/usr/bin/env python3
"""Generate a large deterministic binary content pack during CI.
The pack is intentionally created at build time so the Git repository stays small.
"""
from pathlib import Path
import hashlib
import os

OUT = Path('app/src/main/assets/generated/marketforge_content.pack')
SIZE = 115 * 1024 * 1024
CHUNK = 1024 * 1024
OUT.parent.mkdir(parents=True, exist_ok=True)
seed = b'MarketForge-ULTIMATE-v2-content-pack-2026'
written = 0
counter = 0
with OUT.open('wb') as f:
    header = b'MARKETFORGE_CONTENT_PACK\0' + SIZE.to_bytes(8, 'little')
    f.write(header)
    written += len(header)
    while written < SIZE:
        block = bytearray(CHUNK)
        pos = 0
        while pos < CHUNK:
            digest = hashlib.sha256(seed + counter.to_bytes(8, 'little')).digest()
            take = min(len(digest), CHUNK - pos)
            block[pos:pos+take] = digest[:take]
            pos += take
            counter += 1
        take = min(CHUNK, SIZE - written)
        f.write(block[:take])
        written += take
print(f'Generated {OUT} ({written / 1024 / 1024:.1f} MiB)')
