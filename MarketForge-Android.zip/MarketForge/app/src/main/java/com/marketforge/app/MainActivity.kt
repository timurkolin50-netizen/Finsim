package com.marketforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.random.Random

private val Bg = Color(0xFF0B1016)
private val Panel = Color(0xFF121A23)
private val Panel2 = Color(0xFF172331)
private val Text = Color(0xFFE8EEF4)
private val Muted = Color(0xFF8C9AA8)
private val Green = Color(0xFF21C997)
private val Red = Color(0xFFFF5E68)
private val Cyan = Color(0xFF35C7E8)

data class Asset(
    val ticker: String,
    val name: String,
    val price: Double,
    val change: Double,
    val history: List<Float>
)

data class Holding(val ticker: String, val shares: Int)

data class News(val title: String, val impact: String, val positive: Boolean)

class GameState {
    var cash by mutableStateOf(100_000.0)
    var netWorth by mutableStateOf(100_000.0)
    var day by mutableStateOf(1)
    var selected by mutableStateOf("AUR")
    var assets by mutableStateOf(
        listOf(
            Asset("AUR", "Aurora Robotics", 124.50, 2.8, List(28) { 105f + it * 0.7f + Random.nextFloat() * 12f }),
            Asset("NEX", "Nexon Energy", 78.20, -1.6, List(28) { 92f - it * 0.4f + Random.nextFloat() * 9f }),
            Asset("VLT", "Voltix Systems", 241.30, 4.2, List(28) { 180f + it * 1.9f + Random.nextFloat() * 18f }),
            Asset("MDS", "Medisyn Labs", 56.70, 0.9, List(28) { 50f + it * 0.2f + Random.nextFloat() * 6f })
        )
    )
    var holdings by mutableStateOf(listOf<Holding>())
    var news by mutableStateOf(
        listOf(
            News("Central bank signals softer policy", "+2.1% market sentiment", true),
            News("Supply chain pressure hits energy sector", "-1.4% sector sentiment", false),
            News("Robotics demand reaches new record", "+3.6% AUR catalyst", true)
        )
    )

    fun buy(ticker: String, amount: Int) {
        val a = assets.first { it.ticker == ticker }
        val cost = a.price * amount
        if (amount > 0 && cost <= cash) {
            cash -= cost
            val old = holdings.firstOrNull { it.ticker == ticker }?.shares ?: 0
            holdings = holdings.filterNot { it.ticker == ticker } + Holding(ticker, old + amount)
            refreshWorth()
        }
    }

    fun sell(ticker: String, amount: Int) {
        val a = assets.first { it.ticker == ticker }
        val old = holdings.firstOrNull { it.ticker == ticker }?.shares ?: 0
        val qty = amount.coerceAtMost(old)
        if (qty > 0) {
            cash += a.price * qty
            val left = old - qty
            holdings = if (left == 0) holdings.filterNot { it.ticker == ticker }
            else holdings.filterNot { it.ticker == ticker } + Holding(ticker, left)
            refreshWorth()
        }
    }

    fun nextDay() {
        day++
        assets = assets.map { a ->
            val shock = Random.nextDouble(-0.045, 0.055)
            val p = max(0.5, a.price * (1 + shock))
            a.copy(price = p, change = shock * 100, history = (a.history.drop(1) + p.toFloat()))
        }
        news = listOf(
            News(
                listOf("Merger rumor shakes tech", "New tax proposal pressures growth stocks", "AI orders beat expectations", "Unexpected commodity rally")[Random.nextInt(4)],
                if (Random.nextBoolean()) "+${Random.nextInt(1, 5)}% catalyst" else "-${Random.nextInt(1, 5)}% catalyst",
                Random.nextBoolean()
            )
        ) + news.take(2)
        refreshWorth()
    }

    fun manipulate(positive: Boolean) {
        val a = assets.first { it.ticker == selected }
        val factor = if (positive) 1.12 else 0.88
        assets = assets.map {
            if (it.ticker == selected) {
                val p = it.price * factor
                it.copy(price = p, change = (factor - 1) * 100, history = (it.history.drop(1) + p.toFloat()))
            } else it
        }
        refreshWorth()
    }

    private fun refreshWorth() {
        netWorth = cash + holdings.sumOf { h -> (assets.firstOrNull { it.ticker == h.ticker }?.price ?: 0.0) * h.shares }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketForgeApp() }
    }
}

@Composable
fun MarketForgeApp() {
    val game = remember { GameState() }
    var tab by remember { mutableStateOf(0) }
    var showTrade by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Cyan,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0E141C)) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.CandlestickChart, null) }, label = { Text("Рынок") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.AccountBalance, null) }, label = { Text("Портфель") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Event, null) }, label = { Text("События") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Menu, null) }, label = { Text("Меню") })
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when (tab) {
                    0 -> MarketScreen(game) { showTrade = true }
                    1 -> PortfolioScreen(game)
                    2 -> NewsScreen(game)
                    3 -> MenuScreen(game)
                }
                if (showTrade) {
                    TradeSheet(game) { showTrade = false }
                }
            }
        }
    }
}

@Composable
fun TopBar(game: GameState) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0E141C)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("MARKETFORGE", color = Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("День ${game.day}", color = Muted, fontSize = 12.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("$${money(game.netWorth)}", color = Text, fontWeight = FontWeight.Bold)
            Text("Капитал", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun MarketScreen(game: GameState, onTrade: () -> Unit) {
    val asset = game.assets.first { it.ticker == game.selected }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            TopBar(game)
            Spacer(Modifier.height(12.dp))
            Text("Финансовый рынок", Modifier.padding(horizontal = 16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Симулятор без реальных денег", Modifier.padding(horizontal = 16.dp), color = Muted)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Кэш", "$${money(game.cash)}", Modifier.weight(1f))
                StatCard("Позиции", "${game.holdings.sumOf { it.shares }}", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${asset.ticker} · ${asset.name}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("$${"%.2f".format(asset.price)}", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "${if (asset.change >= 0) "+" else ""}${"%.2f".format(asset.change)}%",
                            color = if (asset.change >= 0) Green else Red,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    PriceChart(asset.history, asset.change >= 0)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        game.assets.forEach { a ->
                            FilterChip(
                                selected = game.selected == a.ticker,
                                onClick = { game.selected = a.ticker },
                                label = { Text(a.ticker) }
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onTrade, Modifier.fillMaxWidth()) {
                        Text("Торговать ${asset.ticker}")
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Последние события", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
        }
        items(game.news) { n ->
            NewsRow(n, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun PortfolioScreen(game: GameState) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            TopBar(game)
            Text("Портфель", Modifier.padding(16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Стоимость портфеля", color = Muted)
                    Text("$${money(game.netWorth)}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Доступно $${money(game.cash)}", color = Green)
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        if (game.holdings.isEmpty()) {
            item {
                Text("Пока нет позиций. Перейди в «Рынок» и купи актив.", Modifier.padding(16.dp), color = Muted)
            }
        } else {
            items(game.holdings) { h ->
                val a = game.assets.first { it.ticker == h.ticker }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(h.ticker, fontWeight = FontWeight.Bold)
                            Text("${h.shares} шт. · $${money(a.price * h.shares)}", color = Muted)
                        }
                        Text("$${"%.2f".format(a.price)}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun NewsScreen(game: GameState) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            TopBar(game)
            Text("События", Modifier.padding(16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Рынок реагирует на новости. Ты можешь ждать, торговать или вмешиваться.", Modifier.padding(horizontal = 16.dp), color = Muted)
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), modifier = Modifier.padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Манипуляция рынка", fontWeight = FontWeight.Bold)
                    Text("Действует на выбранный актив: ${game.selected}", color = Muted)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { game.manipulate(true) }) {
                            Icon(Icons.Default.ArrowUpward, null)
                            Text("Памп")
                        }
                        OutlinedButton(onClick = { game.manipulate(false) }) {
                            Icon(Icons.Default.ArrowDownward, null)
                            Text("Шок")
                        }
                    }
                }
            }
        }
        items(game.news) { NewsRow(it, Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
    }
}

@Composable
fun MenuScreen(game: GameState) {
    Column(Modifier.fillMaxSize()) {
        TopBar(game)
        Text("Игра", Modifier.padding(16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Следующий торговый день", fontWeight = FontWeight.Bold)
                Text("Сгенерировать новый рынок, цены и новости.", color = Muted)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { game.nextDay() }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Закрыть день ${game.day}")
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Правила", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold)
        Text(
            "Это оригинальная учебная экономическая песочница. Все деньги виртуальные. Цены генерируются локально и не являются котировками реального рынка.",
            Modifier.padding(16.dp), color = Muted
        )
    }
}

@Composable
fun TradeSheet(game: GameState, close: () -> Unit) {
    val asset = game.assets.first { it.ticker == game.selected }
    var qty by remember { mutableStateOf(10) }
    AlertDialog(
        onDismissRequest = close,
        containerColor = Panel,
        title = { Text("Торговля ${asset.ticker}") },
        text = {
            Column {
                Text("$${"%.2f".format(asset.price)} за акцию", color = Muted)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { qty = (qty - 1).coerceAtLeast(1) }) { Text("−") }
                    Text("$qty", Modifier.width(70.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { qty++ }) { Text("+") }
                }
                Spacer(Modifier.height(12.dp))
                Text("Сумма: $${money(asset.price * qty)}")
            }
        },
        confirmButton = {
            Button(onClick = { game.buy(asset.ticker, qty); close() }) { Text("Купить") }
        },
        dismissButton = {
            TextButton(onClick = { game.sell(asset.ticker, qty); close() }) { Text("Продать") }
        }
    )
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
fun NewsRow(news: News, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Event, null, tint = if (news.positive) Green else Red)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(news.title, fontWeight = FontWeight.SemiBold)
                Text(news.impact, color = if (news.positive) Green else Red, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PriceChart(values: List<Float>, positive: Boolean) {
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val min = values.minOrNull() ?: 0f
        val max = values.maxOrNull() ?: 1f
        val range = (max - min).coerceAtLeast(1f)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * size.width / (values.size - 1).coerceAtLeast(1)
            val y = size.height - ((v - min) / range) * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = if (positive) Green else Red, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

fun money(v: Double): String = "%,.0f".format(v).replace(',', ' ')
