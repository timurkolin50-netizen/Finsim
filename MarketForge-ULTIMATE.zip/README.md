# MarketForge Ultimate

Полностью оригинальная мобильная финансовая игра в стиле market-management simulator. Она не использует исходный код, брендинг или защищённые ассеты FinSim.

## Что сделано
- живое движение цен почти каждый тик;
- отдельная история цены для каждого актива;
- объём и всплески объёма;
- свечной график;
- order book;
- Time & Sales;
- price impact от размера сделки;
- BUY / SELL / PUMP / DUMP / NEWS SHOCK;
- катализаторы и мировой рынок;
- News Feed;
- регуляторный риск;
- репутация;
- 8 акций из разных секторов;
- портфель и P&L;
- rival funds;
- Career на 8 этапов;
- компания и три ветки развития;
- IPO;
- сохранение прогресса;
- пауза;
- ускоренная симуляция.

## Сборка
JDK 17 + Android SDK 35. GitHub Actions должен запускать `gradle assembleDebug` из найденной папки с `settings.gradle`.

APK: `app/build/outputs/apk/debug/app-debug.apk`
