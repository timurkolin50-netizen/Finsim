
package com.marketforge.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import java.text.*;
import java.util.*;
import android.content.res.Resources;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(6,8,11));
        getWindow().setNavigationBarColor(Color.rgb(6,8,11));
        setContentView(new MarketForgeView(this));
    }
}

class MarketForgeView extends View {
    // ---------- visual system ----------
    static final int BG = Color.rgb(7,9,12);
    static final int SURFACE = Color.rgb(13,17,23);
    static final int SURFACE2 = Color.rgb(18,23,31);
    static final int SURFACE3 = Color.rgb(24,30,39);
    static final int LINE = Color.rgb(39,47,58);
    static final int TEXT = Color.rgb(238,242,247);
    static final int MUTED = Color.rgb(130,141,156);
    static final int BLUE = Color.rgb(85,148,255);
    static final int CYAN = Color.rgb(69,210,232);
    static final int GREEN = Color.rgb(37,216,155);
    static final int RED = Color.rgb(255,91,116);
    static final int GOLD = Color.rgb(247,201,100);
    static final int PURPLE = Color.rgb(176,112,255);
    static final int ORANGE = Color.rgb(255,157,72);

    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler handler = new Handler(Looper.getMainLooper());
    final Random rng = new Random();

    SharedPreferences prefs;
    float d;
    float touchX, touchY;
    int W, H;

    // ---------- market ----------
    static final int N = 8;
    final String[] sym = {"AUR","NEX","VLT","MDS","SKY","CRN","QNT","ARC"};
    final String[] name = {
        "Aurelia Robotics","Nexora Energy","Voltix Systems","Medisage Labs",
        "Skyline Orbital","Crown Retail","Quanta Cloud","Arcadia Motors"
    };
    final String[] sector = {"Robotics","Energy","Semis","Health","Aerospace","Consumer","Cloud","EV"};
    final double[] px = {125.40,82.15,214.80,61.30,44.70,29.15,91.80,73.40};
    final double[] open = px.clone(), prev = px.clone();
    final double[] high = px.clone(), low = px.clone();
    final long[] vol = {185000,310000,244000,122000,208000,355000,280000,198000};
    final long[] avgVol = vol.clone();
    final int[] shares = new int[N];
    final double[] costBasis = new double[N];
    final double[] sentiment = {0.15,-0.08,0.21,0.06,-0.12,0.03,0.14,-0.05};
    ArrayList<Double>[] prices = new ArrayList[N];
    ArrayList<Long>[] vols = new ArrayList[N];

    // ---------- gameplay ----------
    enum Tab { DASHBOARD, MARKET, PORTFOLIO, CAREER, COMPANY, RIVALS }
    Tab tab = Tab.DASHBOARD;
    int selected = 0;
    boolean orderPanel = false;
    boolean newsPanel = false;
    boolean speed2 = false;
    boolean paused = false;

    long cash = 1_000_000;
    double realizedPnl = 0;
    int day = 1;
    int sessionTick = 0;
    int regulator = 0;
    int reputation = 50;
    int xp = 0;
    int level = 1;
    int combo = 0;

    // market microstructure
    int orderQty = 100;
    int orderMode = 1; // 1 buy, -1 sell
    final String[] timeframes = {"1M","5M","15M","1H","1D"};
    int timeframe = 2;
    long totalTrades = 0;
    long turnover = 0;
    long buyPressure = 53;
    long sellPressure = 47;

    // company
    String companyName = "";
    double companyValue = 0;
    int companyLevel = 0;
    int research = 0;
    int production = 0;
    int marketing = 0;

    // career
    int chapter = 1;
    int missionIndex = 0;
    final String[][] missions = {
        {"First Blood","Make your first $10,000 trading profit.","10000"},
        {"Read the Tape","Trade 5,000 shares of any company.","5000"},
        {"Ride the Catalyst","Earn $25,000 during one event.","25000"},
        {"Build a Desk","Reach $2,000,000 net worth.","2000000"},
        {"Move the Market","Create a 5% price move with your orders.","5"},
        {"Whale Hunter","Beat every rival fund in net worth.","1"},
        {"The House","Take a company through IPO.","5000000"},
        {"Empire","Reach $1,000,000,000 net worth.","1000000000"}
    };
    double missionMetric = 0;

    // rivals
    final String[] rivalNames = {"Atlas Whale","Northstar Fund","Black Harbor","Vega Capital"};
    final double[] rivalMoney = {8.5e6,17.2e6,31.4e6,5.9e6};
    final int[] rivalAgg = {60,34,86,48};
    final int[] rivalMood = {0,1,-1,0};

    // feeds
    final ArrayList<String> headlines = new ArrayList<>();
    final ArrayList<String> tape = new ArrayList<>();
    final ArrayList<String> alerts = new ArrayList<>();
    String worldEvent = "CALM MARKET";
    String worldEventDetail = "Liquidity is healthy. Catalysts can appear without warning.";
    int eventTicks = 0;

    MarketForgeView(Context c) {
        super(c);
        d = Resources.getSystem().getDisplayMetrics().density;
        prefs = c.getSharedPreferences("mf_save", Context.MODE_PRIVATE);
        load();
        initSeries();
        seedFeeds();
        text.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        p.setStrokeCap(Paint.Cap.ROUND);
        postLoop();
    }

    void initSeries() {
        for (int i=0;i<N;i++) {
            prices[i] = new ArrayList<>();
            vols[i] = new ArrayList<>();
            double b = px[i];
            for (int j=0;j<110;j++) {
                b = Math.max(0.01, b * (1 + (rng.nextDouble()-0.49)*0.014));
                prices[i].add(b);
                vols[i].add((long)(vol[i]*(0.45+rng.nextDouble()*1.7)));
            }
            high[i]=Math.max(px[i], b); low[i]=Math.min(px[i], b);
        }
    }

    void seedFeeds() {
        if (headlines.isEmpty()) {
            headlines.add("AURELIA ROBOTICS GUIDANCE RAISED");
            headlines.add("CENTRAL BANK HINTS AT A SLOWER CUT PATH");
            headlines.add("CHIP DEMAND BEATS CONSENSUS ESTIMATES");
            headlines.add("ENERGY INVENTORIES SURPRISE TO THE UPSIDE");
            headlines.add("SKYLINE ORBITAL WINS LAUNCH CONTRACT");
        }
        if (tape.isEmpty()) {
            tape.add("09:30:01  MARKET OPEN  •  SPREADS TIGHT");
            tape.add("09:30:02  AUR  BUY  1,000 @ 125.40");
            tape.add("09:30:04  VLT  SELL  850 @ 214.80");
            tape.add("09:30:05  NEX  BUY  2,500 @ 82.15");
        }
    }

    void postLoop() {
        handler.postDelayed(() -> {
            if (!paused) {
                simulate(speed2 ? 2 : 1);
                invalidate();
                save();
            }
            postLoop();
        }, 650);
    }

    void simulate(int n) {
        for (int t=0;t<n;t++) {
            sessionTick++;
            if(eventTicks>0) eventTicks--;
            // correlated market factor
            double market = (rng.nextDouble()-0.48)*0.006;
            double volBurst = rng.nextDouble()<0.07 ? 2.2 : 1.0;

            for(int i=0;i<N;i++) {
                double momentum = 0;
                int sz = prices[i].size();
                if (sz>=8) {
                    momentum = (prices[i].get(sz-1)-prices[i].get(sz-7))/Math.max(prices[i].get(sz-7),0.01) * 0.04;
                }
                double reversion = (open[i]-px[i])/Math.max(open[i],0.01)*0.001;
                double noise = (rng.nextDouble()-0.5)*0.010*volBurst;
                double drift = market + momentum + reversion + sentiment[i]*0.0008 + noise;
                px[i] = Math.max(0.01, px[i]*(1+drift));

                long v = (long)(avgVol[i]*(0.025 + rng.nextDouble()*0.20)*volBurst);
                if (rng.nextDouble()<0.06) v *= 4+rng.nextInt(7);
                vol[i] += Math.max(1,v);
                avgVol[i] = (long)(avgVol[i]*0.9995 + v*0.0005);

                high[i]=Math.max(high[i],px[i]);
                low[i]=Math.min(low[i],px[i]);
                prices[i].add(px[i]);
                vols[i].add(Math.max(1L,v));
                while(prices[i].size()>110)prices[i].remove(0);
                while(vols[i].size()>110)vols[i].remove(0);

                if (rng.nextDouble()<0.16) {
                    String side = rng.nextBoolean() ? "BUY " : "SELL";
                    int q = 100+rng.nextInt(5000);
                    addTape(sym[i]+"  "+side+"  "+fmtInt(q)+" @ "+fmt2(px[i]));
                }
            }

            // catalysts
            if(rng.nextDouble()<0.055) catalyst();
            // rivals
            if(rng.nextDouble()<0.10) rivalActivity();
            // global event
            if(rng.nextDouble()<0.009 && eventTicks<=0) triggerWorldEvent();

            if(sessionTick%55==0){
                day++;
                for(int i=0;i<N;i++){
                    prev[i]=open[i];
                    open[i]=px[i];
                    high[i]=px[i];
                    low[i]=px[i];
                }
                combo=Math.max(0,combo-1);
            }
        }
    }

    void catalyst() {
        int i=rng.nextInt(N);
        boolean good=rng.nextBoolean();
        double move=good ? 0.022+rng.nextDouble()*0.07 : -(0.022+rng.nextDouble()*0.075);
        px[i]=Math.max(.01,px[i]*(1+move));
        sentiment[i]+=good?0.05:-0.06;
        sentiment[i]=Math.max(-1,Math.min(1,sentiment[i]));
        vol[i]+=25000+rng.nextInt(160000);
        headlines.add(0, sym[i]+" "+(good?"SURGES":"PLUNGES")+" AFTER "+(good?"POSITIVE":"NEGATIVE")+" CATALYST");
        if(headlines.size()>14)headlines.remove(headlines.size()-1);
        addTape("ALERT  "+sym[i]+"  CATALYST  "+(move>=0?"+":"")+fmtPct(move*100));
        worldEvent = good ? "EARNINGS BEAT" : "BAD HEADLINE";
        worldEventDetail = name[i]+" just moved on breaking news.";
        eventTicks=30;
        if(Math.abs(move)>0.055) regulator=Math.min(100,regulator+2);
    }

    void rivalActivity() {
        int r=rng.nextInt(rivalNames.length);
        int i=rng.nextInt(N);
        boolean buy=rivalMood[r]>0 ? rng.nextDouble()<0.75 : rivalMood[r]<0 ? rng.nextDouble()<0.35 : rng.nextBoolean();
        int q=500+rng.nextInt(14000);
        double impact=Math.min(.025,Math.sqrt(q/60000.0)*.010);
        px[i]=Math.max(.01,px[i]*(buy?1+impact:1-impact));
        vol[i]+=q;
        rivalMoney[r]*=(1+(rng.nextDouble()-.46)*0.012);
        addTape(rivalNames[r].toUpperCase()+"  "+(buy?"BUY ":"SELL")+"  "+sym[i]+"  "+fmtInt(q));
        rivalMood[r]+=rng.nextBoolean()?1:-1;
        rivalMood[r]=Math.max(-2,Math.min(2,rivalMood[r]));
    }

    void triggerWorldEvent() {
        String[] ev={"RATE SHOCK","COMMODITY CRISIS","AI BOOM","WAR RISK","PANIC SELLING","LIQUIDITY FLOOD"};
        int k=rng.nextInt(ev.length);
        worldEvent=ev[k];
        worldEventDetail=new String[]{
            "Yield curve repriced in minutes. Financials and growth stocks diverge.",
            "Energy prices spike. Transport and industrials reprice.",
            "AI demand explodes. Chips, cloud and robotics lead.",
            "Risk premium jumps. Aerospace rallies while consumers weaken.",
            "Stop losses fire across the market. Volatility is extreme.",
            "Institutional cash floods risk assets. Breadth expands."
        }[k];
        eventTicks=45;
        for(int i=0;i<N;i++){
            double m=(rng.nextDouble()-.45)*.045;
            if(k==2 && (i==0||i==2||i==6))m+=.04;
            if(k==4)m-=.018;
            px[i]=Math.max(.01,px[i]*(1+m));
            vol[i]+=30000+rng.nextInt(240000);
        }
        regulator=Math.min(100,regulator+3);
        alerts.add(0,"WORLD EVENT: "+worldEvent);
        if(alerts.size()>10)alerts.remove(alerts.size()-1);
    }

    // ---------- trading ----------
    void buy(int q) {
        if(q<=0)return;
        long cost=Math.round(px[selected]*q);
        if(cost>cash)return;
        double before=shares[selected]*costBasis[selected];
        shares[selected]+=q;
        costBasis[selected]=(before+cost)/shares[selected];
        cash-=cost;
        totalTrades++;
        turnover+=cost;
        buyPressure=Math.min(99, (long)(buyPressure+Math.max(1,q/400)));
        sellPressure=Math.max(1,100-buyPressure);
        impact(q,true);
        missionMetric+=q;
        xp+=Math.max(1,q/250);
        combo++;
        addTape("YOU  BUY   "+sym[selected]+"  "+fmtInt(q)+" @ "+fmt2(px[selected]));
        if(q>=5000){ regulator=Math.min(100,regulator+4); reputation=Math.max(0,reputation-1); }
    }

    void sell(int q) {
        int a=Math.min(q,shares[selected]);
        if(a<=0)return;
        double proceeds=px[selected]*a;
        realizedPnl+=a*(px[selected]-costBasis[selected]);
        cash+=Math.round(proceeds);
        shares[selected]-=a;
        totalTrades++;
        turnover+=Math.round(proceeds);
        sellPressure=Math.min(99,sellPressure+Math.max(1,a/400));
        buyPressure=Math.max(1,100-sellPressure);
        impact(a,false);
        missionMetric+=a;
        xp+=Math.max(1,a/250);
        combo++;
        addTape("YOU  SELL  "+sym[selected]+"  "+fmtInt(a)+" @ "+fmt2(px[selected]));
        if(a>=5000){ regulator=Math.min(100,regulator+4); reputation=Math.max(0,reputation-1); }
    }

    void impact(int q,boolean buy) {
        double pct=Math.min(.055,Math.sqrt(q/55000.0)*.011);
        px[selected]=Math.max(.01,px[selected]*(buy?1+pct:1-pct));
        vol[selected]+=q;
        prices[selected].add(px[selected]);
        vols[selected].add((long)(q*1.4));
        if(prices[selected].size()>110)prices[selected].remove(0);
        if(vols[selected].size()>110)vols[selected].remove(0);
        if(q>=10000)regulator=Math.min(100,regulator+8);
    }

    void pump() {
        int q=(int)Math.min(50000,Math.max(2500,cash/Math.max(px[selected]*7,1)));
        buy(q);
        reputation=Math.max(0,reputation-4);
        regulator=Math.min(100,regulator+11);
        headlines.add(0,"UNUSUAL BUYING ACTIVITY DETECTED • "+sym[selected]);
    }

    void dump() {
        int q=Math.min(shares[selected],Math.max(2500,shares[selected]/3));
        if(q<=0){ shock(); return; }
        sell(q);
        reputation=Math.max(0,reputation-4);
        regulator=Math.min(100,regulator+11);
    }

    void shock() {
        double before=px[selected];
        px[selected]=Math.max(.01,px[selected]*.78);
        vol[selected]+=80000+rng.nextInt(220000);
        prices[selected].add(px[selected]);
        vols[selected].add(vol[selected]);
        regulator=Math.min(100,regulator+15);
        reputation=Math.max(0,reputation-6);
        addTape("NEWS SHOCK  "+sym[selected]+"  "+fmt2(before)+" → "+fmt2(px[selected]));
        headlines.add(0,"BREAKING: NEGATIVE EVENT HITS "+sym[selected]);
    }

    // ---------- company ----------
    void foundCompany(String n) {
        if(n==null||n.trim().isEmpty()||cash<100000)return;
        companyName=n.trim();
        companyValue=100000;
        companyLevel=1;
        cash-=100000;
        alerts.add(0,"COMPANY FOUNDED • "+companyName);
    }
    void developCompany(int branch) {
        if(companyName.isEmpty())return;
        double cost=50000+companyLevel*25000;
        if(cash<cost)return;
        cash-=(long)cost;
        companyLevel++;
        if(branch==0){research++;companyValue*=1.44;}
        if(branch==1){production++;companyValue*=1.36;}
        if(branch==2){marketing++;companyValue*=1.50;}
        companyValue*=1+(rng.nextDouble()*.10);
        alerts.add(0,companyName+" LEVEL "+companyLevel+" • EXPANSION COMPLETE");
    }
    void ipo() {
        if(companyName.isEmpty()||companyValue<5000000)return;
        cash+=(long)(companyValue*.32);
        reputation=Math.min(100,reputation+15);
        xp+=1000;
        alerts.add(0,"IPO COMPLETE • "+companyName+" WENT PUBLIC");
        companyName="";
        companyValue=0;
        companyLevel=0;
        research=production=marketing=0;
    }

    double netWorth() {
        double n=cash+companyValue;
        for(int i=0;i<N;i++)n+=shares[i]*px[i];
        return n;
    }

    double pnlPct(int i) {
        if(costBasis[i]<=0)return 0;
        return (px[i]-costBasis[i])/costBasis[i]*100;
    }

    // ---------- persistence ----------
    void save() {
        SharedPreferences.Editor e=prefs.edit();
        e.putLong("cash",cash).putInt("day",day).putInt("reg",regulator).putInt("rep",reputation)
            .putInt("xp",xp).putInt("level",level).putString("company",companyName)
            .putLong("companyV",(long)companyValue).putInt("companyL",companyLevel)
            .putInt("chapter",chapter).putInt("mission",missionIndex).apply();
        for(int i=0;i<N;i++){e.putInt("sh"+i,shares[i]);e.putLong("px"+i,(long)(px[i]*100));e.putLong("cb"+i,(long)(costBasis[i]*100));}
        e.apply();
    }
    void load() {
        cash=prefs.getLong("cash",1_000_000);
        day=prefs.getInt("day",1);
        regulator=prefs.getInt("reg",0);
        reputation=prefs.getInt("rep",50);
        xp=prefs.getInt("xp",0);
        level=Math.max(1,prefs.getInt("level",1));
        companyName=prefs.getString("company","");
        companyValue=prefs.getLong("companyV",0);
        companyLevel=prefs.getInt("companyL",0);
        chapter=prefs.getInt("chapter",1);
        missionIndex=prefs.getInt("mission",0);
        for(int i=0;i<N;i++){
            shares[i]=prefs.getInt("sh"+i,0);
            long cp=prefs.getLong("px"+i,(long)(px[i]*100));
            px[i]=cp/100.0;
            costBasis[i]=prefs.getLong("cb"+i,0)/100.0;
            open[i]=prev[i]=px[i];
        }
    }

    // ---------- drawing helpers ----------
    void rect(Canvas c,float l,float t,float r,float b,int color,float rad){
        fill.setColor(color);fill.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,fill);
    }
    void border(Canvas c,float l,float t,float r,float b,int color,float rad){
        line.setColor(color);line.setStyle(Paint.Style.STROKE);line.setStrokeWidth(1*d);c.drawRoundRect(l,t,r,b,rad,rad,line);
    }
    void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        text.setTextSize(size*d);text.setColor(color);text.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(s,x,y,text);
    }
    void center(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        text.setTextSize(size*d);text.setColor(color);text.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(s,x-text.measureText(s)/2,y,text);
    }
    String fmt2(double v){return String.format(Locale.US,"%.2f",v);}
    String fmtPct(double v){return String.format(Locale.US,"%.1f%%",v);}
    String fmtInt(long v){return String.format(Locale.US,"%,d",v);}
    String money(double v){
        double av=Math.abs(v);
        if(av>=1e12)return String.format(Locale.US,"$%.2fT",v/1e12);
        if(av>=1e9)return String.format(Locale.US,"$%.2fB",v/1e9);
        if(av>=1e6)return String.format(Locale.US,"$%.2fM",v/1e6);
        if(av>=1e3)return String.format(Locale.US,"$%.1fK",v/1e3);
        return "$"+String.format(Locale.US,"%.0f",v);
    }
    int valColor(double x){return x>=0?GREEN:RED;}

    void title(Canvas c,String s,String sub){
        txt(c,s,22*d,74*d,25,TEXT,true);
        if(sub!=null)txt(c,sub,22*d,96*d,12,MUTED,false);
    }

    void drawTop(Canvas c){
        rect(c,0,0,W,56*d,SURFACE,0);
        txt(c,"MARKETFORGE",22*d,29*d,15,TEXT,true);
        txt(c,"DAY "+day+"  •  "+worldEvent,145*d,29*d,11,eventTicks>0?GOLD:MUTED,true);
        txt(c,money(netWorth()),W-118*d,25*d,14,TEXT,true);
        txt(c,"CASH",W-118*d,43*d,9,MUTED,true);
        // status
        float x=W-18*d;
        p.setColor(paused?RED:GREEN);c.drawCircle(x,18*d,4*d,p);
    }

    void drawBottom(Canvas c){
        rect(c,0,H-65*d,W,H,SURFACE2,0);
        String[] labels={"HOME","MARKET","PORTFOLIO","CAREER","COMPANY","RIVALS"};
        Tab[] tabs={Tab.DASHBOARD,Tab.MARKET,Tab.PORTFOLIO,Tab.CAREER,Tab.COMPANY,Tab.RIVALS};
        float step=W/6f;
        for(int i=0;i<6;i++){
            if(tab==tabs[i])rect(c,i*step+5*d,H-59*d,(i+1)*step-5*d,H-8*d,SURFACE3,10*d);
            center(c,labels[i],(i+.5f)*step,H-30*d,10,tab==tabs[i]?TEXT:MUTED,tab==tabs[i]);
        }
    }

    void drawDashboard(Canvas c){
        title(c,"COMMAND CENTER","A living market • events • rivals • opportunities");
        drawTopMetrics(c);

        // hero market strip
        rect(c,16*d,112*d,W-16*d,191*d,SURFACE,14*d);
        txt(c,"MARKET PULSE",30*d,135*d,10,MUTED,true);
        txt(c,fmtInt(totalTrades)+" trades",W-135*d,135*d,10,MUTED,false);
        float bx=30*d, bw=(W-60*d)/4f;
        for(int i=0;i<4;i++){
            int s=(i+selected)%N;
            txt(c,sym[s],bx,159*d,12,TEXT,true);
            txt(c,fmt2(px[s]),bx,179*d,15,TEXT,true);
            double ch=(px[s]-prev[s])/Math.max(prev[s],.01)*100;
            txt(c,fmtPct(ch),bx+62*d,178*d,11,valColor(ch),true);
            bx+=bw;
        }

        // event/news
        rect(c,16*d,202*d,W-16*d,315*d,SURFACE,14*d);
        txt(c,"LIVE FEED",30*d,224*d,11,TEXT,true);
        txt(c,worldEvent, W-155*d,224*d,10,eventTicks>0?GOLD:MUTED,true);
        float yy=249*d;
        for(int i=0;i<Math.min(4,headlines.size());i++){
            txt(c,headlines.get(i),30*d,yy,12,TEXT,false);
            yy+=18*d;
            if(i<3){line.setColor(LINE);line.setStrokeWidth(1);c.drawLine(30*d,yy-8*d,W-30*d,yy-8*d,line);}
        }

        // actions
        rect(c,16*d,327*d,W-16*d,443*d,SURFACE,14*d);
        txt(c,"HIGH-IMPACT MOVES",30*d,350*d,11,TEXT,true);
        action(c,30,365,125,420,"BUY / SELL",BLUE);
        action(c,135,365,230,420,"PUMP",GREEN);
        action(c,240,365,335,420,"DUMP",ORANGE);
        action(c,345,365,W/d-30,420,"PANIC SHOCK",RED);

        // mission
        rect(c,16*d,454*d,W-16*d,555*d,SURFACE,14*d);
        txt(c,"NEXT MISSION",30*d,478*d,11,GOLD,true);
        txt(c,missions[missionIndex][0],30*d,500*d,16,TEXT,true);
        txt(c,missions[missionIndex][1],30*d,520*d,11,MUTED,false);
        float progress=(float)Math.min(1,missionMetric/Double.parseDouble(missions[missionIndex][2]));
        rect(c,30*d,532*d,W-30*d,538*d,LINE,3*d);
        rect(c,30*d,532*d,30*d+(W-60*d)*progress,538*d,GOLD,3*d);
        txt(c,fmtInt((long)Math.min(missionMetric,Double.parseDouble(missions[missionIndex][2])))+" / "+fmtInt((long)Double.parseDouble(missions[missionIndex][2])),30*d,552*d,10,MUTED,false);
    }

    void drawTopMetrics(Canvas c){
        float y=109*d, gap=8*d, w=(W-32*d-2*gap)/3f;
        metric(c,16,y,w,"NET WORTH",money(netWorth()),GREEN);
        metric(c,16+w+gap,y,w,"REGULATOR",regulator+"%",regulator>65?RED:GOLD);
        metric(c,16+2*(w+gap),y,w,"REPUTATION",""+reputation,BLUE);
    }

    void metric(Canvas c,float x,float y,float w,String a,String b,int color){
        rect(c,x,y,x+w,y+58*d,SURFACE,11*d);
        txt(c,a,x+11*d,y+19*d,9,MUTED,true);
        txt(c,b,x+11*d,y+43*d,16,color,true);
    }

    void action(Canvas c,float x,float y,float r,float b,String label,int color){
        rect(c,x*d,y*d,r*d,b*d,color,12*d);
        center(c,label,(x+r)/2*d,(y+33)*d,10,BG,true);
    }

    void drawMarket(Canvas c){
        title(c,"MARKET","Real-time price + volume + order flow");
        // ticker row
        float top=108*d;
        for(int i=0;i<N;i++){
            float x=12*d+i*92*d;
            boolean sel=i==selected;
            rect(c,x,top,x+86*d,top+45*d,sel?SURFACE3:SURFACE,8*d);
            txt(c,sym[i],x+8*d,top+16*d,11,sel?TEXT:MUTED,true);
            txt(c,fmt2(px[i]),x+8*d,top+34*d,12,TEXT,true);
            double ch=(px[i]-prev[i])/Math.max(prev[i],.01)*100;
            txt(c,(ch>=0?"+":"")+fmtPct(ch),x+48*d,top+34*d,9,valColor(ch),true);
        }

        float chartTop=164*d;
        rect(c,12*d,chartTop,W-12*d,510*d,SURFACE,14*d);
        drawChartHeader(c,chartTop);
        drawCandles(c,22*d,chartTop+52*d,W-175*d,chartTop+300*d);
        drawVolume(c,22*d,chartTop+315*d,W-175*d,chartTop+390*d);
        drawOrderBook(c,W-160*d,chartTop+52*d,W-22*d,chartTop+390*d);

        // order entry
        rect(c,12*d,521*d,W-12*d,620*d,SURFACE,14*d);
        txt(c,"ORDER TICKET",24*d,544*d,10,MUTED,true);
        txt(c,sym[selected]+"  "+fmt2(px[selected]),24*d,567*d,15,TEXT,true);
        qtyButton(c,24,580,"−"); center(c,""+orderQty,72*d,599*d,13,TEXT,true); qtyButton(c,88,580,"+");
        button(c,125,578,205,608,"BUY",GREEN, true);
        button(c,212,578,292,608,"SELL",RED, true);
        button(c,300,578,394,608,"PUMP",PURPLE, true);
        button(c,402,578,W/d-24,608,"DUMP",ORANGE, true);

        // tape footer
        rect(c,12*d,631*d,W-12*d, H-76*d,SURFACE,14*d);
        txt(c,"TIME & SALES",24*d,654*d,10,MUTED,true);
        float yy=676*d;
        for(int i=0;i<Math.min(5,tape.size());i++){
            txt(c,tape.get(i),24*d,yy,10,i==0?TEXT:MUTED,false);
            yy+=18*d;
        }
    }

    void drawChartHeader(Canvas c,float y){
        txt(c,sym[selected]+"  "+name[selected],24*d,y+24*d,15,TEXT,true);
        txt(c,sector[selected],24*d,y+41*d,10,MUTED,false);
        double ch=(px[selected]-prev[selected])/Math.max(prev[selected],.01)*100;
        txt(c,fmt2(px[selected]),W-165*d,y+27*d,17,TEXT,true);
        txt(c,(ch>=0?"+":"")+fmtPct(ch),W-165*d,y+44*d,10,valColor(ch),true);
        // timeframe chips
        float x=W-158*d;
        for(String tf:timeframes){
            border(c,x,y+7*d,x+27*d,y+27*d,LINE,6*d);
            center(c,tf,x+13.5f*d,y+21*d,7,MUTED,true);
            x+=30*d;
        }
    }

    void drawCandles(Canvas c,float l,float t,float r,float b){
        // grid
        for(int k=0;k<5;k++){
            float y=t+(b-t)*k/4f;
            line.setColor(GRID);line.setStrokeWidth(1);c.drawLine(l,y,r,y,line);
        }
        ArrayList<Double> s=prices[selected];
        int n=Math.min(70,s.size());
        double lo=Double.MAX_VALUE,hi=-Double.MAX_VALUE;
        for(int i=s.size()-n;i<s.size();i++){lo=Math.min(lo,s.get(i));hi=Math.max(hi,s.get(i));}
        double pad=(hi-lo)*.09+0.0001;hi+=pad;lo-=pad;
        int step=6;
        for(int i=0;i<n;i++){
            int idx=s.size()-n+i;
            double close=s.get(idx);
            double openp=i==0?s.get(Math.max(0,idx-1)):s.get(idx-1);
            // pseudo intrabar from neighboring close to create candle bodies
            double highp=Math.max(close,openp)*(1+0.001+rngHash(idx)*0.003);
            double lowp=Math.min(close,openp)*(1-0.001-rngHash(idx+7)*0.003);
            float x=l+i*(r-l)/(float)Math.max(1,n-1);
            float yo=map(openp,lo,hi,t,b), yc=map(close,lo,hi,t,b);
            float yh=map(highp,lo,hi,t,b), yl=map(lowp,lo,hi,t,b);
            int color=close>=openp?GREEN:RED;
            p.setColor(color);p.setStrokeWidth(1.2f*d);
            c.drawLine(x,yh,x,yl,p);
            float bodyW=Math.max(2*d,(r-l)/n*0.58f);
            float top=Math.min(yo,yc),bot=Math.max(yo,yc);
            p.setStyle(Paint.Style.FILL);c.drawRect(x-bodyW/2,top,x+bodyW/2,Math.max(bot,top+2*d),p);
        }
        // last price line
        float yl=map(px[selected],lo,hi,t,b);
        line.setColor(BLUE);line.setStrokeWidth(1.3f*d);c.drawLine(l,yl,r,yl,line);
        rect(c,r-68*d,yl-10*d,r,yl+10*d,BLUE,4*d);
        center(c,fmt2(px[selected]),r-34*d,yl+4*d,8,BG,true);
    }

    double rngHash(int n){
        double x=Math.sin(n*12.9898)*43758.5453;
        return x-Math.floor(x);
    }

    float map(double v,double lo,double hi,float t,float b){
        return (float)(b-(v-lo)/(hi-lo)*(b-t));
    }

    void drawVolume(Canvas c,float l,float t,float r,float b){
        txt(c,"VOLUME",l,t+14*d,8,MUTED,true);
        ArrayList<Long> s=vols[selected];
        int n=Math.min(70,s.size());
        long max=1;
        for(int i=s.size()-n;i<s.size();i++)max=Math.max(max,s.get(i));
        for(int i=0;i<n;i++){
            long v=s.get(s.size()-n+i);
            float x=l+i*(r-l)/(float)n;
            float hh=(v/(float)max)*(b-t-18*d);
            p.setColor((i%2==0)?Color.rgb(51,84,110):Color.rgb(38,69,89));
            c.drawRect(x,t+18*d,x+(r-l)/n-.5f,b-hh,p);
        }
        txt(c,"AVG "+fmtInt(avgVol[selected]),r-92*d,t+14*d,8,MUTED,true);
    }

    void drawOrderBook(Canvas c,float l,float t,float r,float b){
        txt(c,"ORDER BOOK",l,t,9,TEXT,true);
        float y=t+22*d;
        for(int i=0;i<6;i++){
            long q=500+Math.round(rngHash(i+selected*13)*7000);
            double p1=px[selected]+(i+1)*0.07;
            double p2=px[selected]-(i+1)*0.07;
            txt(c,fmtInt(q),l,y,8,MUTED,false);
            txt(c,fmt2(p1),r-65*d,y,9,RED,false);
            y+=18*d;
        }
        line.setColor(LINE);line.setStrokeWidth(1);c.drawLine(l,y-5*d,r,y-5*d,line);
        txt(c,fmt2(px[selected]),l,y+8*d,10,GOLD,true);
        y+=27*d;
        for(int i=0;i<6;i++){
            long q=500+Math.round(rngHash(i+55+selected*9)*8500);
            double p1=px[selected]-(i+1)*0.07;
            txt(c,fmtInt(q),l,y,8,MUTED,false);
            txt(c,fmt2(p1),r-65*d,y,9,GREEN,false);
            y+=18*d;
        }
    }

    void qtyButton(Canvas c,float x,float y,String s){
        rect(c,x*d,y*d,(x+28)*d,(y+28)*d,SURFACE3,7*d);
        center(c,s,(x+14)*d,(y+19)*d,13,TEXT,true);
    }

    void button(Canvas c,float x,float y,float r,float b,String s,int color,boolean mini){
        rect(c,x*d,y*d,r*d,b*d,color,8*d);
        center(c,s,(x+r)/2*d,(y+(b-y)*.66f)*d,mini?9:11,BG,true);
    }

    void drawPortfolio(Canvas c){
        title(c,"PORTFOLIO","Positions, exposure, P&L and risk");
        rect(c,14*d,111*d,W-14*d,182*d,SURFACE,14*d);
        txt(c,"EQUITY",28*d,132*d,9,MUTED,true);
        txt(c,money(netWorth()),28*d,158*d,21,TEXT,true);
        txt(c,"REALIZED",W/2,132*d,9,MUTED,true);
        txt(c,money(realizedPnl),W/2,158*d,16,valColor(realizedPnl),true);
        txt(c,"TURNOVER",W-126*d,132*d,9,MUTED,true);
        txt(c,money(turnover),W-126*d,158*d,16,TEXT,true);

        float y=198*d;
        for(int i=0;i<N;i++){
            if(shares[i]<=0)continue;
            rect(c,14*d,y,W-14*d,y+64*d,SURFACE,11*d);
            txt(c,sym[i],28*d,y+22*d,13,TEXT,true);
            txt(c,fmtInt(shares[i])+" shares",28*d,y+42*d,10,MUTED,false);
            txt(c,money(shares[i]*px[i]),W-150*d,y+23*d,13,TEXT,true);
            double pp=pnlPct(i);
            txt(c,(pp>=0?"+":"")+fmtPct(pp),W-150*d,y+43*d,10,valColor(pp),true);
            y+=72*d;
        }
        if(y<260*d)txt(c,"No positions yet. Enter the market to start your book.",24*d,y+35*d,12,MUTED,false);

        rect(c,14*d,Math.min(y,H-150*d),W-14*d,Math.min(y,H-150*d)+95*d,SURFACE,14*d);
        txt(c,"RISK",28*d,Math.min(y,H-150*d)+23*d,10,MUTED,true);
        txt(c,"Regulator attention",28*d,Math.min(y,H-150*d)+47*d,11,TEXT,false);
        rect(c,185*d,Math.min(y,H-150*d)+39*d,W-30*d,Math.min(y,H-150*d)+47*d,LINE,4*d);
        rect(c,185*d,Math.min(y,H-150*d)+39*d,185*d+(W-215*d)*regulator/100f,Math.min(y,H-150*d)+47*d,regulator>65?RED:GOLD,4*d);
        txt(c,"Leverage-free • liquidity OK",28*d,Math.min(y,H-150*d)+72*d,10,MUTED,false);
    }

    void drawCareer(Canvas c){
        title(c,"CAREER","Eight chapters • choices • unlocks • escalating stakes");
        int y=112;
        rect(c,14*d,y*d,W-14*d,(y+112)*d,SURFACE,14*d);
        txt(c,"CHAPTER "+chapter,28*d,(y+27)*d,11,GOLD,true);
        txt(c,missions[missionIndex][0],28*d,(y+53)*d,18,TEXT,true);
        txt(c,missions[missionIndex][1],28*d,(y+76)*d,11,MUTED,false);
        double target=Double.parseDouble(missions[missionIndex][2]);
        float prog=(float)Math.min(1,missionMetric/target);
        rect(c,28*d,(y+88)*d,W-28*d,(y+95)*d,LINE,4*d);
        rect(c,28*d,(y+88)*d,28*d+(W-56*d)*prog,(y+95)*d,GOLD,4*d);
        txt(c,fmtInt((long)Math.min(missionMetric,target))+" / "+fmtInt((long)target),28*d,(y+108)*d,9,MUTED,false);

        y=236;
        txt(c,"UNLOCK TREE",22*d,y*d,11,TEXT,true);
        String[] unlock={"LIVE TERMINAL","ORDER FLOW","NEWS CATALYSTS","RIVAL WHALES","COMPANY BUILDER","IPO","WORLD EVENTS","BILLIONAIRE MODE"};
        for(int i=0;i<8;i++){
            int col=i%2,row=i/2;
            float x=14*d+col*(W/2f);
            float yy=(y+16+row*58)*d;
            boolean on=i<chapter+3;
            rect(c,x,yy,x+W/2f-10*d,yy+46*d,on?SURFACE3:SURFACE,10*d);
            txt(c,on?"✓":"•",x+12*d,yy+28*d,14,on?GREEN:MUTED,true);
            txt(c,unlock[i],x+33*d,yy+27*d,9,on?TEXT:MUTED,on);
        }
    }

    void drawCompany(Canvas c){
        title(c,"COMPANY LAB","Grow legally • specialize • IPO");
        if(companyName.isEmpty()){
            rect(c,14*d,112*d,W-14*d,270*d,SURFACE,14*d);
            txt(c,"FOUND YOUR COMPANY",28*d,140*d,12,GOLD,true);
            txt(c,"Starting capital: $100,000",28*d,164*d,13,TEXT,true);
            txt(c,"Build a moat, scale operations and take the company public.",28*d,188*d,11,MUTED,false);
            button(c,28,215,200,252,"FOUND AURORA",BLUE,false);
            txt(c,"Tap to create a fictional startup. No real money involved.",28*d,285*d,9,MUTED,false);
        } else {
            rect(c,14*d,112*d,W-14*d,214*d,SURFACE,14*d);
            txt(c,companyName,28*d,143*d,20,TEXT,true);
            txt(c,"Private company • Level "+companyLevel,28*d,164*d,10,MUTED,false);
            txt(c,money(companyValue),28*d,196*d,23,GREEN,true);
            txt(c,"Valuation",28*d,209*d,9,MUTED,false);

            rect(c,14*d,226*d,W-14*d,430*d,SURFACE,14*d);
            txt(c,"GROWTH TREE",28*d,250*d,11,TEXT,true);
            branch(c,28,269, "R&D",research,GOLD);
            branch(c,28,335,"Production",production,BLUE);
            branch(c,28,401,"Marketing",marketing,PURPLE);
            button(c,30,449,145,482,"DEVELOP",GREEN,true);
            button(c,154,449,269,482,"SCALE",BLUE,true);
            button(c,278,449,W/d-30,482,"IPO",GOLD,true);
            txt(c,"IPO requirement: valuation ≥ $5M",30*d,505*d,10,MUTED,false);
        }
    }

    void branch(Canvas c,float x,float y,String s,int lvl,int color){
        rect(c,x*d,y*d,W-28*d,(y+52)*d,SURFACE2,9*d);
        txt(c,s,x*d+12*d,(y+20)*d,10,TEXT,true);
        for(int i=0;i<5;i++){
            float xx=(x+110+i*28)*d;
            p.setColor(i<Math.min(lvl,5)?color:LINE);
            c.drawCircle(xx,(y+25)*d,6*d,p);
        }
        txt(c,"Lv "+lvl,x*d+12*d,(y+40)*d,9,MUTED,false);
    }

    void drawRivals(Canvas c){
        title(c,"RIVAL FUNDS","They trade, react and compete for the top spot");
        txt(c,"YOUR EQUITY  "+money(netWorth()),22*d,112*d,11,GOLD,true);
        int y=136;
        for(int i=0;i<4;i++){
            rect(c,14*d,y*d,W-14*d,(y+84)*d,SURFACE,13*d);
            txt(c,rivalNames[i],28*d,(y+25)*d,14,TEXT,true);
            txt(c,money(rivalMoney[i]),28*d,(y+47)*d,13,valColor(rivalMood[i]),true);
            String rel=rivalMood[i]>0?"BULLISH":rivalMood[i]<0?"AGGRESSIVE":"NEUTRAL";
            txt(c,rel,W-106*d,(y+25)*d,9,rivalMood[i]<0?RED:mutedColor(rivalMood[i]),true);
            txt(c,"AGG "+rivalAgg[i]+"/100",W-106*d,(y+48)*d,9,MUTED,false);
            rect(c,28*d,(y+62)*d,W-28*d,(y+69)*d,LINE,4*d);
            float fillw=(W-56*d)*rivalAgg[i]/100f;
            rect(c,28*d,(y+62)*d,28*d+fillw,(y+69)*d,rivalAgg[i]>70?RED:GOLD,4*d);
            y+=96;
        }
        rect(c,14*d,y*d,W-14*d,(y+83)*d,SURFACE,13*d);
        txt(c,"TACTICAL OPPORTUNITY",28*d,(y+25)*d,10,GOLD,true);
        txt(c,"Watch rivals concentrate volume.",28*d,(y+48)*d,12,TEXT,true);
        txt(c,"When they move size, follow the tape — or fade them.",28*d,(y+68)*d,10,MUTED,false);
    }

    int mutedColor(int n){return n>0?GREEN:MUTED;}

    // ---------- touch ----------
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){touchX=e.getX();touchY=e.getY();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=e.getX()/d,y=e.getY()/d;
            handleTap(x,y);
            return true;
        }
        return true;
    }

    void handleTap(float x,float y){
        // bottom tabs
        if(y>H/d-75){
            int idx=(int)(x/(W/6f));
            switch(idx){
                case 0:tab=Tab.DASHBOARD;break;case 1:tab=Tab.MARKET;break;case 2:tab=Tab.PORTFOLIO;break;
                case 3:tab=Tab.CAREER;break;case 4:tab=Tab.COMPANY;break;case 5:tab=Tab.RIVALS;break;
            }
            invalidate();return;
        }

        if(tab==Tab.DASHBOARD){
            if(y>365&&y<425){
                if(x<130){buy(1000);}
                else if(x<235)pump();
                else if(x<340)dump();
                else shock();
            } else if(y>112&&y<190){
                selected=(selected+1)%N;tab=Tab.MARKET;
            } else if(y<60){paused=!paused;}
        } else if(tab==Tab.MARKET){
            if(y>=105&&y<=160){
                int idx=(int)((x-12)/(92));
                if(idx>=0&&idx<N)selected=idx;
            } else if(y>555&&y<620){
                if(x<110)orderQty=Math.max(10,orderQty-10);
                else if(x<150)orderQty=Math.min(100000,orderQty+10);
                else if(x<215)buy(orderQty);
                else if(x<300)sell(orderQty);
                else if(x<398)pump();
                else dump();
            } else if(y>164&&y<510){
                timeframe=(timeframe+1)%timeframes.length;
            }
        } else if(tab==Tab.PORTFOLIO){
            if(y<180)tab=Tab.MARKET;
        } else if(tab==Tab.CAREER){
            if(y>112&&y<230){
                if(y>180){advanceMission();}
            }
        } else if(tab==Tab.COMPANY){
            if(companyName.isEmpty() && y>205&&y<280){foundCompany("Aurora Labs");}
            else if(!companyName.isEmpty() && y>440&&y<515){
                if(x<150)developCompany(0);
                else if(x<275)developCompany(1);
                else ipo();
            }
        } else if(tab==Tab.RIVALS){
            if(y>500) { selected=(selected+1)%N;tab=Tab.MARKET; }
        }
        invalidate();
    }

    void advanceMission(){
        double target=Double.parseDouble(missions[missionIndex][2]);
        if(missionMetric>=target){
            missionMetric=0;
            missionIndex++;
            if(missionIndex>=missions.length){missionIndex=0;chapter++;}
            chapter=Math.min(8,1+missionIndex);
            xp+=500;
            level=1+xp/1000;
            alerts.add(0,"MISSION COMPLETE • NEXT CHAPTER UNLOCKED");
        }
    }
}
