package com.marketforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private val Bg = Color(0xFF0B0E12)
private val Panel = Color(0xFF131820)
private val Panel2 = Color(0xFF1A2029)
private val TextMain = Color(0xFFE7EBF0)
private val Muted = Color(0xFF8E98A8)
private val Green = Color(0xFF38D39F)
private val Red = Color(0xFFFF647C)
private val Blue = Color(0xFF65A8FF)
private val Gold = Color(0xFFF2C96D)

data class Stock(
    val symbol: String,
    val name: String,
    val sector: String,
    val price: Double,
    val change: Double,
    val history: List<Double>,
    val owned: Int = 0
)

data class News(val title: String, val body: String, val impact: String)
data class Rival(val name: String, val cash: Double, val relation: String, val aggression: Int)

class MarketViewModel : ViewModel() {
    var cash by mutableStateOf(1_000_000.0)
    var netWorth by mutableStateOf(1_000_000.0)
    var day by mutableStateOf(1)
    var selected by mutableStateOf("AUR")
    var regulator by mutableStateOf(0)
    var reputation by mutableStateOf(50)
    var mode by mutableStateOf("Free Play")
    var companyValue by mutableStateOf(0.0)
    var companyName by mutableStateOf("")

    var stocks by mutableStateOf(
        listOf(
            Stock("AUR", "Aurelia Robotics", "Robotics", 125.40, 2.7, seed(125.4)),
            Stock("NEX", "Nexora Energy", "Energy", 82.15, -1.3, seed(82.15)),
            Stock("VLT", "Voltix Systems", "Semiconductors", 214.80, 4.8, seed(214.8)),
            Stock("MDS", "Medisage Labs", "Healthcare", 61.30, 0.9, seed(61.3)),
            Stock("SKY", "Skyline Orbital", "Aerospace", 44.70, -3.2, seed(44.7)),
            Stock("CRN", "Crown Retail", "Consumer", 29.15, 1.1, seed(29.15))
        )
    )

    var news by mutableStateOf(
        listOf(
            News("Central bank signals slower cuts", "Risk assets react as traders reprice the next quarter.", "Mixed"),
            News("Aurelia wins defense contract", "AUR demand expectations jump.", "AUR +8%"),
            News("Energy inventory surprise", "Energy names face short-term pressure.", "NEX -6%")
        )
    )

    var rivals by mutableStateOf(
        listOf(
            Rival("Atlas Whale", 8_500_000.0, "Neutral", 62),
            Rival("Northstar Fund", 17_200_000.0, "Friend", 34),
            Rival("Black Harbor", 31_400_000.0, "Enemy", 88)
        )
    )

    var careerChapter by mutableStateOf(1)
    var mission by mutableStateOf("Make your first $100,000 trading profit.")
    var missionProgress by mutableStateOf(0.0)

    fun selectedStock(): Stock = stocks.first { it.symbol == selected }

    fun buy(symbol: String, qty: Int) {
        if (qty <= 0) return
        val idx = stocks.indexOfFirst { it.symbol == symbol }
        val s = stocks[idx]
        val cost = s.price * qty
        if (cash < cost) return
        cash -= cost
        val impact = min(0.08, qty / 50000.0)
        val ns = s.copy(
            price = s.price * (1 + impact),
            change = s.change + impact * 100,
            history = (s.history + s.price * (1 + impact)).takeLast(80),
            owned = s.owned + qty
        )
        stocks = stocks.toMutableList().also { it[idx] = ns }
        recalc()
        missionProgress += cost
        regulator = min(100, regulator + if (qty > 5000) 2 else 0)
    }

    fun sell(symbol: String, qty: Int) {
        if (qty <= 0) return
        val idx = stocks.indexOfFirst { it.symbol == symbol }
        val s = stocks[idx]
        val actual = min(qty, s.owned)
        if (actual <= 0) return
        cash += s.price * actual
        val impact = min(0.08, actual / 50000.0)
        val ns = s.copy(
            price = max(0.01, s.price * (1 - impact)),
            change = s.change - impact * 100,
            history = (s.history + s.price * (1 - impact)).takeLast(80),
            owned = s.owned - actual
        )
        stocks = stocks.toMutableList().also { it[idx] = ns }
        recalc()
        regulator = min(100, regulator + if (actual > 5000) 2 else 0)
    }

    fun pump() {
        val s = selectedStock()
        buy(s.symbol, max(1, (s.price * 2500 / max(s.price, 1.0)).toInt()))
        regulator = min(100, regulator + 8)
        reputation = max(0, reputation - 3)
        news = listOf(News("Unusual buying activity", "${s.symbol} is moving sharply as large orders hit the tape.", "Pump")) + news.take(6)
    }

    fun shock() {
        val idx = stocks.indexOfFirst { it.symbol == selected }
        val s = stocks[idx]
        val drop = 0.12
        val ns = s.copy(price = s.price * (1-drop), change = s.change - 12, history = (s.history + s.price*(1-drop)).takeLast(80))
        stocks = stocks.toMutableList().also { it[idx] = ns }
        regulator = min(100, regulator + 10)
        reputation = max(0, reputation - 5)
        news = listOf(News("Breaking: supply disruption", "${s.name} is hit by a sudden negative shock.", "Shock")) + news.take(6)
        recalc()
    }

    fun nextDay() {
        day++
        val rng = Random(day * 17 + 9)
        stocks = stocks.map { s ->
            val drift = (rng.nextDouble() - 0.47) * 0.045
            val p = max(0.01, s.price * (1 + drift))
            s.copy(price = p, change = drift * 100, history = (s.history + p).takeLast(80))
        }
        if (rng.nextDouble() < 0.22) {
            val s = stocks.random(rng)
            news = listOf(
                News("Global market event", "${s.name} is affected by a new macro event.", if (rng.nextBoolean()) "Positive" else "Negative")
            ) + news.take(6)
        }
        regulator = max(0, regulator - 1)
        rivals = rivals.map { r ->
            val delta = rng.nextDouble(-0.03, 0.06)
            r.copy(cash = max(0.0, r.cash * (1 + delta)))
        }
        recalc()
        missionProgress = max(missionProgress, netWorth - 1_000_000)
    }

    fun startCompany(name: String) {
        if (cash < 100_000 || name.isBlank()) return
        cash -= 100_000
        companyName = name
        companyValue = 100_000
        recalc()
    }

    fun growCompany(multiplier: Double) {
        if (companyName.isBlank()) return
        val cost = max(25_000.0, companyValue * 0.12)
        if (cash < cost) return
        cash -= cost
        companyValue *= multiplier
        recalc()
    }

    fun ipo() {
        if (companyName.isBlank() || companyValue < 5_000_000) return
        cash += companyValue * 0.25
        companyValue = 0.0
        companyName = ""
        reputation = min(100, reputation + 10)
        recalc()
    }

    private fun recalc() {
        netWorth = cash + stocks.sumOf { it.price * it.owned } + companyValue
    }

    companion object {
        private fun seed(start: Double): List<Double> {
            var p = start
            return List(55) {
                p *= 1 + Random.nextDouble(-0.018, 0.022)
                p = max(0.01, p)
                p
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketForgeApp() }
    }
}

@Composable
fun MarketForgeApp(vm: MarketViewModel = viewModel()) {
    var tab by remember { mutableStateOf("Dashboard") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Blue,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            TopBar(vm)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "Dashboard" -> Dashboard(vm, { tab = it })
                    "Market" -> Market(vm)
                    "Portfolio" -> Portfolio(vm)
                    "Career" -> Career(vm)
                    "Company" -> Company(vm)
                    "Rivals" -> Rivals(vm)
                }
            }
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
fun TopBar(vm: MarketViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("MARKETFORGE", fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("${vm.mode}  •  Day ${vm.day}", color = Muted, fontSize = 12.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("$${money(vm.netWorth)}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Cash $${money(vm.cash)}", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun Dashboard(vm: MarketViewModel, nav: (String) -> Unit) {
    Screen {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("NET WORTH", "$${money(vm.netWorth)}", Green, Modifier.weight(1f))
            Stat("REGULATOR", "${vm.regulator}%", if (vm.regulator > 60) Red else Gold, Modifier.weight(1f))
            Stat("REPUTATION", "${vm.reputation}", Blue, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        CardBox {
            Text("MARKET", fontWeight = FontWeight.Bold)
            Text("Select an asset and trade, manipulate the tape, or wait for the next trading day.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { nav("Market") }) { Text("Open market") }
                OutlinedButton(onClick = { vm.nextDay() }) { Text("Next day") }
            }
        }
        CardBox {
            Text("LATEST NEWS", fontWeight = FontWeight.Bold)
            vm.news.take(4).forEach {
                Spacer(Modifier.height(8.dp))
                Text(it.title, fontWeight = FontWeight.SemiBold)
                Text(it.body, color = Muted, fontSize = 12.sp)
                Text(it.impact, color = if (it.impact.contains("-")) Red else Green, fontSize = 11.sp)
            }
        }
        CardBox {
            Text("QUICK ACTIONS", fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Pump", Green) { vm.pump() }
                ActionButton("Shock", Red) { vm.shock() }
                ActionButton("Portfolio", Blue) { nav("Portfolio") }
                ActionButton("Career", Gold) { nav("Career") }
            }
        }
    }
}

@Composable
fun Market(vm: MarketViewModel) {
    Screen {
        Text("MARKET", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.stocks.forEach { s ->
                FilterChip(
                    selected = vm.selected == s.symbol,
                    onClick = { vm.selected = s.symbol },
                    label = { Text(s.symbol) }
                )
            }
        }
        val s = vm.selectedStock()
        CardBox {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("${s.symbol}  ${s.name}", fontWeight = FontWeight.Bold)
                    Text(s.sector, color = Muted, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("$${"%.2f".format(s.price)}", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("${if (s.change >= 0) "+" else ""}${"%.2f".format(s.change)}%", color = if (s.change >= 0) Green else Red)
                }
            }
            Spacer(Modifier.height(12.dp))
            PriceChart(s.history)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.buy(s.symbol, 100) }) { Text("Buy 100") }
                OutlinedButton(onClick = { vm.sell(s.symbol, 100) }) { Text("Sell 100") }
            }
        }
        CardBox {
            Text("MARKET ACTIONS", fontWeight = FontWeight.Bold)
            Text("Large orders move price. Aggressive manipulation increases regulator attention.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("PUMP + NEWS", Green) { vm.pump() }
                ActionButton("SHOCK", Red) { vm.shock() }
            }
        }
        CardBox {
            Text("NEWS FEED", fontWeight = FontWeight.Bold)
            vm.news.forEach { n ->
                Spacer(Modifier.height(7.dp))
                Text(n.title, fontWeight = FontWeight.SemiBold)
                Text(n.body, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun Portfolio(vm: MarketViewModel) {
    Screen {
        Text("PORTFOLIO", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        CardBox {
            Text("Cash", color = Muted)
            Text("$${money(vm.cash)}", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Positions", color = Muted)
            Text("$${money(vm.stocks.sumOf { it.price * it.owned })}", fontSize = 20.sp)
        }
        vm.stocks.filter { it.owned > 0 }.ifEmpty {
            item {
                CardBox { Text("No open positions. Go to Market and buy an asset.") }
            }
        }.forEach { s ->
            CardBox {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${s.symbol} • ${s.name}", fontWeight = FontWeight.Bold)
                        Text("${s.owned} shares", color = Muted)
                    }
                    Text("$${money(s.price * s.owned)}", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun Career(vm: MarketViewModel) {
    Screen {
        Text("CAREER", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        CardBox {
            Text("Chapter ${vm.careerChapter}", color = Gold, fontWeight = FontWeight.Bold)
            Text(vm.mission, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (vm.missionProgress / 100_000.0).coerceIn(0.0, 1.0).toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text("$${money(vm.missionProgress)} / $100,000", color = Muted, fontSize = 12.sp)
        }
        CardBox {
            Text("CAREER LOOP", fontWeight = FontWeight.Bold)
            Text("Trade → complete missions → unlock new tools → build a company → IPO.", color = Muted)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { vm.buy(vm.selected, 500) }) { Text("Execute mission trade") }
        }
        CardBox {
            Text("UNLOCK ROADMAP", fontWeight = FontWeight.Bold)
            listOf("Trading terminal", "Market events", "Rival whales", "Company growth tree", "IPO", "World crisis").forEachIndexed { i, t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (i < vm.careerChapter + 2) "✓" else "•", color = if (i < vm.careerChapter + 2) Green else Muted)
                    Spacer(Modifier.width(8.dp))
                    Text(t)
                }
            }
        }
    }
}

@Composable
fun Company(vm: MarketViewModel) {
    Screen {
        Text("COMPANY BUILDER", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (vm.companyName.isBlank()) {
            var name by remember { mutableStateOf("") }
            CardBox {
                Text("Found a company", fontWeight = FontWeight.Bold)
                Text("Starting capital: $100,000", color = Muted)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Company name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.startCompany(name) }) { Text("Found company") }
            }
        } else {
            CardBox {
                Text(vm.companyName, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Private company", color = Muted)
                Spacer(Modifier.height(8.dp))
                Text("Valuation: $${money(vm.companyValue)}", fontSize = 20.sp)
            }
            CardBox {
                Text("GROWTH TREE", fontWeight = FontWeight.Bold)
                Text("Research → production → distribution → global expansion", color = Muted)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.growCompany(1.35) }) { Text("Develop") }
                    OutlinedButton(onClick = { vm.growCompany(1.8) }) { Text("Scale") }
                }
            }
            CardBox {
                Text("IPO", fontWeight = FontWeight.Bold)
                Text("Requirement: valuation ≥ $5,000,000", color = Muted)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.ipo() }, enabled = vm.companyValue >= 5_000_000) { Text("Take public") }
            }
        }
    }
}

@Composable
fun Rivals(vm: MarketViewModel) {
    Screen {
        Text("RIVAL WHALES", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("AI rivals react to your positions and can become allies or enemies.", color = Muted)
        vm.rivals.forEach { r ->
            CardBox {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(r.name, fontWeight = FontWeight.Bold)
                        Text("${r.relation} • aggression ${r.aggression}/100", color = if (r.relation == "Enemy") Red else Muted, fontSize = 12.sp)
                    }
                    Text("$${money(r.cash)}", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { r.aggression / 100f }, modifier = Modifier.fillMaxWidth())
            }
        }
        CardBox {
            Text("ATTACK TOOLS", fontWeight = FontWeight.Bold)
            Text("Use market shocks and aggressive order flow to fight rivals.", color = Muted)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Attack", Red) { vm.shock() }
                ActionButton("Pump", Green) { vm.pump() }
            }
        }
    }
}

@Composable
fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
        content = content
    )
}

@Composable
fun Stat(title: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(10.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 9.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun ActionButton(text: String, color: Color, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = color)) {
        Text(text, color = Bg, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PriceChart(values: List<Double>) {
    Canvas(
        Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF0E131A), RoundedCornerShape(8.dp))
    ) {
        if (values.size < 2) return@Canvas
        val lo = values.minOrNull() ?: 0.0
        val hi = values.maxOrNull() ?: 1.0
        val range = max(hi - lo, 0.0001)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size - 1).toFloat()
            val y = size.height - ((v - lo) / range).toFloat() * size.height * 0.82f - size.height * 0.08f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = Green, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
    }
}

@Composable
fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    val tabs = listOf("Dashboard", "Market", "Portfolio", "Career", "Company", "Rivals")
    Row(
        Modifier.fillMaxWidth().background(Panel).horizontalScroll(rememberScrollState()).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        tabs.forEach { t ->
            Text(
                t,
                modifier = Modifier
                    .background(if (selected == t) Panel2 else Color.Transparent, RoundedCornerShape(8.dp))
                    .clickable { onSelect(t) }
                    .padding(horizontal = 11.dp, vertical = 10.dp),
                color = if (selected == t) TextMain else Muted,
                fontSize = 11.sp,
                fontWeight = if (selected == t) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

fun money(v: Double): String {
    return when {
        v >= 1_000_000_000_000 -> "%.2fT".format(v / 1_000_000_000_000)
        v >= 1_000_000_000 -> "%.2fB".format(v / 1_000_000_000)
        v >= 1_000_000 -> "%.2fM".format(v / 1_000_000)
        v >= 1_000 -> "%.1fK".format(v / 1_000)
        else -> "%.0f".format(v)
    }
}
